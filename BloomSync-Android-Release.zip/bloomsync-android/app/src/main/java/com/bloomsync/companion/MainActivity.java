package com.bloomsync.companion;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.google.androidbrowserhelper.trusted.LauncherActivity;

/** Opens the hosted BloomSync app in the user's browser-backed app session. */
public final class MainActivity extends LauncherActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Remove URL/share payloads but preserve Android's task flags. Browser
        // Helper relaunches this activity when FLAG_ACTIVITY_NEW_TASK is missing;
        // dropping that flag on every onCreate causes a relaunch/finish loop.
        int launchFlags = getIntent().getFlags();
        setIntent(new Intent(this, MainActivity.class)
                .setAction(Intent.ACTION_MAIN)
                .setFlags(launchFlags));
        super.onCreate(savedInstanceState);
    }

    @Override
    protected Uri getLaunchingUrl() {
        return Uri.parse(getString(R.string.launch_url));
    }
}
