package com.bloomsync.companion;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import android.content.Intent;
import android.net.Uri;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.robolectric.Robolectric;
import org.robolectric.RobolectricTestRunner;
import org.robolectric.RuntimeEnvironment;
import org.robolectric.Shadows;
import org.robolectric.android.controller.ActivityController;
import org.robolectric.annotation.Config;

/** Exercises the actual Browser Helper activity lifecycle, without a browser service. */
@RunWith(RobolectricTestRunner.class)
@Config(sdk = 28)
public class MainActivityLaunchTest {
    @Test
    public void launcherStartPreservesTaskFlagsWithoutRelaunchingItself() {
        int flags = Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED;
        Intent incoming = new Intent(RuntimeEnvironment.getApplication(), MainActivity.class)
                .setAction(Intent.ACTION_MAIN)
                .setFlags(flags)
                .setData(Uri.parse("https://example.invalid/ignored"))
                .putExtra("untrusted_share_payload", "ignored");

        ActivityController<MainActivity> controller =
                Robolectric.buildActivity(MainActivity.class, incoming);
        try {
            MainActivity activity = controller.create().get();
            assertEquals(flags, activity.getIntent().getFlags());
            assertNull(activity.getIntent().getData());
            assertNull(activity.getIntent().getExtras());
            assertNoSelfRelaunch(activity);
        } finally {
            controller.destroy();
        }
    }

    @Test
    public void launchWithoutNewTaskRestartsOnceThenReachesBrowserHandoff() {
        Intent incoming = new Intent(RuntimeEnvironment.getApplication(), MainActivity.class)
                .setAction(Intent.ACTION_MAIN);
        ActivityController<MainActivity> first =
                Robolectric.buildActivity(MainActivity.class, incoming);
        Intent restarted;
        try {
            MainActivity activity = first.create().get();
            restarted = Shadows.shadowOf(activity).getNextStartedActivity();
            assertNotNull("Browser Helper should add NEW_TASK through one restart", restarted);
            assertNotNull(restarted.getComponent());
            assertEquals(MainActivity.class.getName(), restarted.getComponent().getClassName());
            assertTrue((restarted.getFlags() & Intent.FLAG_ACTIVITY_NEW_TASK) != 0);
        } finally {
            first.destroy();
        }

        ActivityController<MainActivity> second =
                Robolectric.buildActivity(MainActivity.class, restarted);
        try {
            MainActivity activity = second.create().get();
            assertTrue((activity.getIntent().getFlags() & Intent.FLAG_ACTIVITY_NEW_TASK) != 0);
            assertNoSelfRelaunch(activity);
        } finally {
            second.destroy();
        }
    }

    private static void assertNoSelfRelaunch(MainActivity activity) {
        Intent next;
        while ((next = Shadows.shadowOf(activity).getNextStartedActivity()) != null) {
            if (next.getComponent() != null
                    && MainActivity.class.getName().equals(next.getComponent().getClassName())) {
                fail("Launch loop: MainActivity restarted instead of handing off to the browser");
            }
        }
        // Browser Helper can normally finish after handing off to the browser.
        // isFinishing() alone must not be mistaken for a startup failure.
    }
}
