plugins {
    id("com.android.application")
}

val releaseKeyPath = providers.environmentVariable("ANDROID_KEYSTORE_PATH").orNull
val releaseStorePassword = providers.environmentVariable("ANDROID_KEYSTORE_PASSWORD").orNull
val releaseAlias = providers.environmentVariable("ANDROID_KEY_ALIAS").orNull
val releaseKeyPassword = providers.environmentVariable("ANDROID_KEY_PASSWORD").orNull

android {
    namespace = "com.bloomsync.companion"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.bloomsync.companion"
        minSdk = 24
        targetSdk = 36
        versionCode = providers.environmentVariable("ANDROID_VERSION_CODE")
            .orElse("1").get().toInt()
        versionName = "1.0.1"
    }

    signingConfigs {
        create("release") {
            storeType = "PKCS12"
            storeFile = releaseKeyPath?.let { file(it) }
            storePassword = releaseStorePassword
            keyAlias = releaseAlias
            keyPassword = releaseKeyPassword
        }
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-preview"
            resValue("string", "launcher_name", "BloomSync Preview")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
            resValue("string", "launcher_name", "BloomSync")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    testOptions {
        unitTests.isIncludeAndroidResources = true
        unitTests.all {
            it.jvmArgs(
                "--add-opens=java.base/java.lang=ALL-UNNAMED",
                "--add-opens=java.base/java.util=ALL-UNNAMED",
                "--add-opens=java.base/java.io=ALL-UNNAMED",
                "--add-opens=java.base/java.net=ALL-UNNAMED",
                "--add-opens=java.base/java.security=ALL-UNNAMED",
                "--add-opens=java.base/java.text=ALL-UNNAMED",
                "--add-opens=java.base/jdk.internal.access=ALL-UNNAMED",
                "--add-opens=java.desktop/java.awt.font=ALL-UNNAMED",
                "--add-opens=jdk.compiler/com.sun.tools.javac.api=ALL-UNNAMED"
            )
        }
    }
}

val checkReleaseCredentials by tasks.registering {
    doLast {
        check(listOf(releaseKeyPath, releaseStorePassword, releaseAlias, releaseKeyPassword)
            .all { !it.isNullOrBlank() }) {
            "Release signing is not configured. Follow docs/SIGNING.md or build assembleDebug."
        }
        check(file(requireNotNull(releaseKeyPath)).isFile) {
            "The release keystore file does not exist."
        }
    }
}

tasks.matching { it.name == "preReleaseBuild" }.configureEach {
    dependsOn(checkReleaseCredentials)
}

dependencies {
    implementation("com.google.androidbrowserhelper:androidbrowserhelper:2.7.4")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.robolectric:robolectric:4.16.1")
}
