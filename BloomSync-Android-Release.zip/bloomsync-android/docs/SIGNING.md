# Permanent release signing

Use the separate PRIVATE-BloomSync-Signing-Key.zip supplied for this release. It contains your encrypted PKCS12 keystore and four Actions-secret value files. Do not upload the private archive, keystore or text files to GitHub repository files. Add only each value to its corresponding repository Actions secret. See the root README for the exact sequence.

The app release signing configuration explicitly uses PKCS12. The workflow checks the decoded public certificate against release-verification/certificate-sha256.txt before building. Reuse this exact key for updates; keep the private backup secure.

For a local build set ANDROID_KEYSTORE_PATH to the absolute .p12 path, plus ANDROID_KEYSTORE_PASSWORD, ANDROID_KEY_ALIAS and ANDROID_KEY_PASSWORD in your environment. Set ANDROID_VERSION_CODE higher than the installed release, then run:

```sh
gradle --no-daemon :app:assembleRelease :app:bundleRelease :app:lintRelease
```

If using Play App Signing, the certificate Google uses for installed APKs may differ from this upload certificate. Add the Play signing fingerprint to the website association file before expecting a fullscreen TWA from Play.
