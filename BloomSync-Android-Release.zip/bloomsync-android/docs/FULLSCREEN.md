# Website verification

This release uses the public certificate in release-verification/release-certificate.der. Its SHA-256 fingerprint and matching assetlinks.json are in the same folder. The private key is supplied separately and must never be published.

The website must publicly serve the association JSON at:
https://bloomsync-clear-demo.weddinginvitation67.chatgpt.site/.well-known/assetlinks.json

Expected response: HTTPS 200, application/json, no login or redirect. The hosted-site update is prepared alongside this release; confirm the live response and Android browser verification before claiming fullscreen is tested.

The app-side statement is already in app/src/main/res/values/strings.xml. After a successful signed build, install BloomSync.apk using an updated supported browser. If verification fails, a browser bar remains. External sign-in origins can show browser controls. If Google Play re-signs the bundle, include its app signing certificate too.

Reference: https://developer.chrome.com/docs/android/trusted-web-activity/quick-start
