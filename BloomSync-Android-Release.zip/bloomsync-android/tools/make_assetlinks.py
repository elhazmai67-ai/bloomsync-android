#!/usr/bin/env python3
"""Create website verification JSON using a public signing certificate fingerprint."""
import argparse
import json
import re
from pathlib import Path


def normalize_fingerprint(value):
    compact = re.sub(r"[:\s]", "", value)
    if not re.fullmatch(r"[0-9a-fA-F]{64}", compact):
        raise ValueError("Expected a SHA-256 certificate fingerprint: 64 hex digits.")
    compact = compact.upper()
    return ":".join(compact[i:i + 2] for i in range(0, 64, 2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--fingerprint", help="Public SHA-256 signing certificate fingerprint")
    source.add_argument("--certificate-file", type=Path, help="Output of apksigner --print-certs")
    parser.add_argument("--package", default="com.bloomsync.companion")
    parser.add_argument("--output", type=Path, default=Path("assetlinks.json"))
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+", args.package):
        parser.error("Invalid Android package name.")
    value = args.fingerprint
    if args.certificate_file:
        matches = re.findall(r"^Signer #\d+ certificate SHA-256 digest:\s*([0-9a-fA-F:]+)\s*$",
                             args.certificate_file.read_text(), re.MULTILINE)
        if len(matches) != 1:
            parser.error("Expected exactly one signing certificate SHA-256 digest.")
        value = matches[0]
    try:
        fingerprint = normalize_fingerprint(value)
    except ValueError as error:
        parser.error(str(error))
    result = [{
        "relation": ["delegate_permission/common.handle_all_urls"],
        "target": {
            "namespace": "android_app",
            "package_name": args.package,
            "sha256_cert_fingerprints": [fingerprint],
        },
    }]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"Created {args.output} for {args.package}")


if __name__ == "__main__":
    main()
