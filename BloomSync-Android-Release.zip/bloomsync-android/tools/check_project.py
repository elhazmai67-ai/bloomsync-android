#!/usr/bin/env python3
"""Check configuration before the Android SDK build. Uses Python standard library."""
import json
from pathlib import Path
import re
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "app/src/main/res"
ANDROID = "{http://schemas.android.com/apk/res/android}"


def main():
    trees = {path: ET.parse(path) for path in (ROOT / "app/src/main").rglob("*.xml")}
    strings = {node.attrib["name"]: node.text for node in trees[RES / "values/strings.xml"].getroot()}
    origin = "https://bloomsync-clear-demo.weddinginvitation67.chatgpt.site"
    assert strings["launch_url"] == origin + "/", "Unexpected launch URL"
    statement = json.loads(strings["asset_statements"].replace('\\"', '"'))
    assert statement[0]["target"] == {"namespace": "web", "site": origin}
    assert statement[0]["relation"] == ["delegate_permission/common.handle_all_urls"]

    known_resources = {("string", "launcher_name")}
    for path, tree in trees.items():
        if path.parent.name.startswith("values"):
            for node in tree.getroot():
                if "name" in node.attrib:
                    known_resources.add((node.tag, node.attrib["name"]))
        elif path.is_relative_to(RES):
            known_resources.add((path.parent.name.split("-")[0], path.stem))
    for path, tree in trees.items():
        for node in tree.iter():
            for value in node.attrib.values():
                if re.fullmatch(r"@[a-z_]+/[a-z_]+", value):
                    kind, name = value[1:].split("/")
                    assert (kind, name) in known_resources, f"Missing {value} in {path}"

    manifest = trees[ROOT / "app/src/main/AndroidManifest.xml"].getroot()
    app = manifest.find("application")
    assert app.attrib[ANDROID + "usesCleartextTraffic"] == "false"
    assert app.attrib[ANDROID + "allowBackup"] == "false"
    permissions = {item.attrib[ANDROID + "name"] for item in manifest.findall("uses-permission")}
    assert permissions == {"android.permission.INTERNET"}
    activity = app.find("activity")
    assert activity.attrib[ANDROID + "name"] == ".MainActivity"
    metadata = {node.attrib[ANDROID + "name"]: node.attrib for node in activity.findall("meta-data")}
    prefix = "android.support.customtabs.trusted."
    assert metadata[prefix + "FALLBACK_STRATEGY"][ANDROID + "value"] == "customtabs"
    assert metadata[prefix + "DEFAULT_URL"][ANDROID + "value"] == "@string/launch_url"
    assert not manifest.findall(".//data"), "This launcher does not register deep links."

    gradle = (ROOT / "app/build.gradle.kts").read_text()
    assert 'applicationId = "com.bloomsync.companion"' in gradle
    assert 'applicationIdSuffix = ".debug"' in gradle
    assert 'minSdk = 24' in gradle and 'compileSdk = 36' in gradle
    assert 'androidbrowserhelper:2.7.4' in gradle
    assert (ROOT / ".github/workflows/build-apk.yml").is_file()
    for path in ROOT.rglob("*"):
        if path.is_file() and "build" not in path.parts and ".gradle" not in path.parts:
            assert path.suffix not in {".jks", ".keystore", ".pem", ".key"}, f"Do not commit signing keys: {path}"
    print(f"Project configuration OK: {len(trees)} XML files, resource references, URL and package settings.")
    print("Android compilation and lint are separate GitHub Actions steps.")


if __name__ == "__main__":
    try:
        main()
    except (AssertionError, ValueError, ET.ParseError) as error:
        print(f"Configuration error: {error}", file=sys.stderr)
        sys.exit(1)
