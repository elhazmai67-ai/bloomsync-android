# BloomSync signed Android release

This release setup uses a permanent PKCS12 signing key, the app name BloomSync, package `com.bloomsync.companion`, and the simple rose/cream heart icon. The workflow builds a non-debuggable release APK and an AAB, runs Android lint, verifies the APK signature, and checks the package and app label.

## Startup fix in 1.0.1

The earlier MainActivity replaced Android's launch intent and dropped its task flags. Android Browser Helper then relaunched MainActivity with NEW_TASK; the wrapper dropped that flag again and could close or loop before opening the browser. Version 1.0.1 preserves task flags while still removing incoming URL/share payloads.

Two Robolectric lifecycle regression tests cover normal launcher startup and the one-time restart from an intent without NEW_TASK. The release workflow runs them before creating the downloadable APK. A passing build still needs phone checks for browser handoff, sign-in and pairing.

Reuse the existing permanent signing backup and the same four GitHub Secrets. The website certificate association is unchanged. GitHub must use Build BloomSync Release, not the older Build APK preview workflow.

## Phone se GitHub par setup

1. Repository ke Code tab par `BloomSync-Android-Release.zip` poori file upload karo. Extract karna zaroori nahi. Filename exactly yahi rakho.
2. `PRIVATE-BloomSync-Signing-Key.zip` sirf apne phone par extract karo. **Is private ZIP ya uski files ko repository, Issues, Actions artifacts ya Releases mein upload mat karo.**
3. Repository → Settings → Secrets and variables → Actions → New repository secret.
4. Private ZIP ki chaar `ANDROID_*.txt` files se chaar secrets banao. Har file ka naam `.txt` ke bina secret ka Name hai. Us file ka poora text secret ki Value hai. Passwords/chat mein bhejne ki zaroorat nahi.
5. Repository mein `.github/workflows/build-apk.yml` kholo aur old workflow ko supplied `build-bloomsync-release.yml` ke poore code se replace karo. Filename `.github/workflows/build-apk.yml` hi rakho. Main branch par Commit changes karo.
6. Actions → Build BloomSync Release. Commit par run start ho sakti hai. Zarurat ho to Run workflow → main → Run workflow.
7. Green tick ke baad run ke Artifacts mein `BloomSync-Release-…` download karo. ZIP extract karke `BloomSync.apk` install karo.

| GitHub Actions secret | Private backup file |
| --- | --- |
| ANDROID_KEYSTORE_BASE64 | ANDROID_KEYSTORE_BASE64.txt |
| ANDROID_KEYSTORE_PASSWORD | ANDROID_KEYSTORE_PASSWORD.txt |
| ANDROID_KEY_ALIAS | ANDROID_KEY_ALIAS.txt |
| ANDROID_KEY_PASSWORD | ANDROID_KEY_PASSWORD.txt |

Public project ZIP, workflow YAML and files inside `release-verification/` contain no private signing key or passwords. The separate PRIVATE backup is sensitive and must remain private. It contains the permanent encrypted `.p12` plus its passwords for recovery; keep the entire backup secure. Do not generate a fresh key for each build. The workflow reuses your Actions secrets and rejects a mismatched signing certificate.

## What this release contains

- `BloomSync.apk`: signed release for direct Android installation.
- `BloomSync.aab`: signed app bundle, for a separate Play Console release process. Store account, policy review and publishing are not performed here.
- `certificate.txt`, `assetlinks.json`, `SHA256SUMS.txt`, `apk-info.txt`: public verification details.
- No `Preview` suffix and no `.debug` package in the release.

## App behaviour

This is an Android Browser Helper / Trusted Web Activity app connected to the current hosted BloomSync service:
https://bloomsync-clear-demo.weddinginvitation67.chatgpt.site/

It uses that website's interface, login and pairing backend. It requires internet, the hosted service, Android 7+ and a supported updated browser. It does not bundle an offline copy of the website or a separate native database. The release signing configuration does not itself create new UI or change account permissions.

The website association statement for the supplied key is included in `release-verification/assetlinks.json`. The exact public website path is `/.well-known/assetlinks.json`. Browser verification must succeed for the app origin to open without browser controls; external sign-in origins can still show browser controls. Native phone behaviour must be tested after installation. If Google Play re-signs the AAB using Play App Signing, add the Play signing certificate to the website association file as well.

## Updates and backups

The workflow uses the GitHub run number for `versionCode`. Keep the same workflow/repository for increasing numbers. If moving repositories or resetting the workflow, ensure the next version code exceeds the installed release. Reuse the same package and permanent signing key for updates. Keep an independent secure copy of the PRIVATE backup.

This is a new app package, not a signed update to the earlier `com.bloomsync.periodtracker` APK. Old local APK data is not automatically imported. Hosted account data remains with that account.

## Verification status

The encrypted key, certificate match, ZIP contents, YAML/shell syntax and Android resource/configuration checks were validated locally. The new Robolectric tests and Android compilation/lint have not been run locally because the Android build tools are unavailable. APK installation, login, fullscreen and two-device pairing also require device verification. GitHub Actions performs compilation/lint/signature checks; the Android device checks follow a successful build.

Build tools: JDK 17, Gradle 8.13, AGP 8.13.2, SDK 36, Build Tools 35.0.0, Android Browser Helper 2.7.4. Local builds use Gradle installed separately; no Gradle wrapper JAR is bundled.

Official references:
- https://developer.android.com/studio/publish/app-signing
- https://developer.chrome.com/docs/android/trusted-web-activity/quick-start
- https://docs.github.com/en/actions/security-for-github-actions/security-guides/using-secrets-in-github-actions
