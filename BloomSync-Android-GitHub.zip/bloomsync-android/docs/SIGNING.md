# Signed release APK

Debug APK pehle test kar lo. Release ke liye apni signing key ek baar banao aur usi key ko future updates mein reuse karo. Private key ya password GitHub repository mein commit mat karo.

## 1. Create and back up a key

JDK 17 ke `keytool` se project folder ke bahar:

```sh
keytool -genkeypair -v -keystore bloomsync-release.jks -storetype JKS -alias bloomsync -keyalg RSA -keysize 3072 -validity 10000
```

Prompts par store password, certificate details aur key password set karo. Key password ko store password jaisa rakhna ho to prompt par Enter use kar sakte ho. Certificate details apni honi chahiye. Keystore aur passwords ka secure backup rakho.

Keystore wale folder mein Python 3 se base64 text file banao:

```sh
python3 -c "import base64,pathlib; pathlib.Path('keystore-base64.txt').write_text(base64.b64encode(pathlib.Path('bloomsync-release.jks').read_bytes()).decode())"
```

Base64 text bhi private key jitna sensitive hai. Secret save karne ke baad temporary text file delete karo; original keystore ka secure backup rakho.

## 2. GitHub Secrets add karo

Repository → Settings → Secrets and variables → Actions → New repository secret:

| Secret name | Value |
| --- | --- |
| `ANDROID_KEYSTORE_BASE64` | `keystore-base64.txt` ka poora content |
| `ANDROID_KEYSTORE_PASSWORD` | Keystore/store password |
| `ANDROID_KEY_ALIAS` | `bloomsync` (ya jo alias tumne choose kiya) |
| `ANDROID_KEY_PASSWORD` | Key password |

Workflow key ko temporary runner file mein decode karta hai, build ke baad delete karta hai, aur key/password ko artifact mein include nahi karta. Apne repository collaborators aur workflow edits par control rakho: workflow access wale trusted maintainers signing secrets use kar sakte hain.

## 3. Build release

Actions → Build APK → Run workflow → `variant: release`. Green tick ke baad `BloomSync-release-…` artifact download karo. Usmein `BloomSync-release.apk`, public certificate details, APK checksum aur website verification JSON hoga.

Preview aur release packages alag hain, isliye dono install ho sakte hain. Release APK ko next release se update karne ke liye package name + signing key same, aur `versionCode` higher hona chahiye. Workflow `github.run_number` use karta hai; repository/workflow replace karte waqt version code ka dhyan rakho. Public release se pehle `versionName` in `app/build.gradle.kts` bhi update kar sakte ho.

## Local release build (optional)

JDK, Gradle aur SDK setup ke baad ye environment variables apne terminal/IDE mein set karo. Values ko repo file mein save mat karo:

- `ANDROID_KEYSTORE_PATH`: absolute path to your `.jks`
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`
- `ANDROID_VERSION_CODE`: existing release se greater positive integer

Then:

```sh
gradle --no-daemon :app:assembleRelease :app:lintRelease
```

Play Store publishing is a separate step. If Play App Signing is used later, website verification must include the **Play app signing certificate**, not just the upload key.
