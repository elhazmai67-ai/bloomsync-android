# Fullscreen / address bar setup

This project uses Android Browser Helper. A Trusted Web Activity removes browser UI only after the browser verifies that the website and the installed APK belong together. Until then it falls back to a Custom Tab with browser controls. The website and login still use a browser session.

## Configure after the first signed release build

1. Build `release` using your permanent signing key (see [SIGNING.md](SIGNING.md)).
2. Download the release artifact. Its `assetlinks.json` is generated from the actual APK signing certificate. `certificate.txt` records that public fingerprint. No private signing key is included.
3. Have the hosted website serve that exact JSON at:

   `https://bloomsync-clear-demo.weddinginvitation67.chatgpt.site/.well-known/assetlinks.json`

4. It must be a publicly accessible HTTPS response with HTTP 200 and `Content-Type: application/json`, with no login requirement or redirect. In a compatible website source project the static file is commonly placed at `public/.well-known/assetlinks.json`; verify that the deployed host actually serves this path as JSON and does not return the app HTML or an auth page.
5. Install that same signed release APK on an Android device with updated Chrome. Open it and verify that the app origin loads without the address bar. Browser verification can be cached; after a corrected deployment allow the browser to re-check or test a fresh installation/browser profile.

**The current hosted site has not been changed to publish your signing certificate.** You can send the generated `assetlinks.json` back for the website change; it contains a public fingerprint, not your key. If the hosting service does not allow a public file at that exact path, fullscreen verification will need hosting that supports it. Do not disable browser verification to hide the bar.

## Generate JSON manually

From project root, using the *public certificate SHA-256 fingerprint*:

```sh
python3 tools/make_assetlinks.py --fingerprint YOUR_CERTIFICATE_SHA256 --output assetlinks.json
```

The command rejects placeholders; replace `YOUR_CERTIFICATE_SHA256` with the real 64 hexadecimal digits, optionally colon-separated. This is the certificate digest, **not** the APK file checksum in `SHA256SUMS.txt`.

Or use `apksigner verify --verbose --print-certs` output:

```sh
python3 tools/make_assetlinks.py --certificate-file certificate.txt --output assetlinks.json
```

Default release package: `com.bloomsync.companion`. Preview package: `com.bloomsync.companion.debug`. To test preview verification, pass `--package com.bloomsync.companion.debug`; however temporary CI debug signing keys are not suitable for a stable deployment. If supporting multiple packages/certificates, merge valid statements/fingerprints with the site's existing file instead of overwriting unrelated entries.

## App-side configuration

`app/src/main/res/values/strings.xml` already contains the app-to-website statement and launch URL for the current BloomSync origin. There is deliberately no Android URL intent filter, so this launcher does not intercept website login callbacks. Its Activity opens the configured URL only.

Changing the website domain requires updating both `launch_url` and `asset_statements`, then rebuilding the APK and publishing the verification file on the new origin. Sign-in pages on other origins may show browser controls even when the main app origin is verified.

Reference: https://developer.chrome.com/docs/android/trusted-web-activity/integration-guide
