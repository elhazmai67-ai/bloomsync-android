# BloomSync — Android APK project

Is folder ko GitHub par upload karke APK bana sakte ho. App ka simple rose + cream heart icon hai. APK existing live BloomSync app kholta hai, isliye updated Check-in, Together, calendar, mood colours aur account-based pairing wahi website se milte hain.

**Live app:** https://bloomsync-clear-demo.weddinginvitation67.chatgpt.site/

## Sabse pehle: APK kaise banaye

1. `BloomSync-Android-GitHub.zip` **extract** karo.
2. GitHub par ek empty repository banao, jaise `bloomsync-android`.
3. Extracted `bloomsync-android` folder ke **andar ki files aur folders** repository ke root mein upload karo. Root par `app`, `tools`, `build.gradle.kts`, `settings.gradle.kts` aur `.github` hone chahiye.
4. Check karo ki GitHub par **`.github/workflows/build-apk.yml`** dikh raha hai. Phone/file manager hidden folders chhupata ho to “Show hidden files” on karo. Zarurat ho to GitHub → Add file → Create new file se isi exact path par workflow ki poori file paste karo.
5. **Actions → Build APK → Run workflow → variant: debug → Run workflow**. `main` ya `master` par pehla upload bhi debug build automatically start karta hai.
6. Green tick aane ke baad us run ko kholo. Niche **Artifacts** mein `BloomSync-debug-…` download karo.
7. Downloaded artifact ZIP extract karo aur **`BloomSync-preview.apk`** install karo. Android agar installation permission maange, apne browser/file manager ke liye allow karo.

**Sirf project ZIP ko GitHub par upload karne se APK build nahi hoga. Files extract karke upload karni hain.** Workflow default branch par hona chahiye, aur repository mein Actions enabled hone chahiye. GitHub ka Actions/artifact access tumhare account settings aur available quota par depend karega.

## Is project mein kya milta hai

| Cheez | Behaviour |
| --- | --- |
| Android support | Android 7.0 / API 24 aur newer |
| Test build | `BloomSync Preview`, package `com.bloomsync.companion.debug`; signing secrets ki zarurat nahi |
| Release build | `BloomSync`, package `com.bloomsync.companion`; apni permanent signing key chahiye |
| Icon | Simple cream heart, rose background; adaptive, round aur Android themed icon resources |
| App UI | Existing hosted BloomSync website; latest website updates APK rebuild ke bina load hote hain |
| Login and sync | Browser-backed session; same hosted accounts and pairing backend |
| Internet | Required. Website hosting available rehna chahiye |
| Browser | Updated Chrome recommended; Android Browser Helper uses an available supported browser |

Yeh Android launcher source project hai. Website ka server/database is ZIP mein bundled nahi hai; woh existing hosted app par chalta hai. GitHub Pages par upload karne se BloomSync ka authentication/database backend create nahi hota.

**Pehli build mein address/browser bar dikhna expected hai.** Fullscreen Trusted Web Activity ke liye website aur APK ke signing certificate ki verification configure karni hogi. Complete steps [docs/FULLSCREEN.md](docs/FULLSCREEN.md) mein hain. Verification available na ho to app supported browser ke Custom Tab mein khulta hai. Sign-in ke dauran doosre origin par browser bar dikh sakti hai.

## Pairing / live sync

1. APK mein **Enable live sync** se apna account/profile open karo.
2. Partner apne device par apne alag account se sign in kare.
3. Partner section mein invite code aur approval flow complete karo; sharing choices check karo.
4. Check-in save karo. Paired device online aur app open hone par shared mood update receive karta hai.

Preview/demo mode mein real accounts pair nahi hote. APK apne aap kisi ko pair nahi karta. Journal notes private rehte hain. Current hosted app open hone par lagbhag 3-second polling use karta hai; yeh background push notification service nahi hai. Native APK se two-device login/pairing ko install karne ke baad verify karna abhi baaki hai.

## Release APK aur future updates

Pehle debug se install/login test kar lo. Share karne aur consistent future updates ke liye [docs/SIGNING.md](docs/SIGNING.md) follow karke `release` build banao.

Debug builds GitHub ke temporary runner ke debug certificate se sign hote hain. Nayi run ki signing identity badal sakti hai; agar preview update install na ho to purana **BloomSync Preview** uninstall karke fresh preview install karo. Release key ko permanently safe rakhna; release updates mein wahi key aur higher version code use hona chahiye. Workflow version code ke liye GitHub run number use karta hai.

Yeh naya Android package hai. Purane `com.bloomsync.periodtracker` APK ka signed update nahi hai. Purane APK ka local data automatically import nahi hota. Hosted account data usi hosted account se milta hai.

## Build tools / local build

- JDK 17
- Gradle 8.13
- Android Gradle Plugin 8.13.2
- Android SDK platform 36 and Build Tools 35.0.0
- Android Browser Helper 2.7.4

GitHub workflow in tools ko setup karta hai. ZIP mein Gradle wrapper JAR bundled nahi hai; workflow `gradle/actions/setup-gradle` se exact Gradle version install karta hai. Local build ke liye wahi Gradle version install karo, Android SDK configure karo, phir project root se:

```sh
python3 tools/check_project.py
gradle --no-daemon :app:assembleDebug :app:lintDebug
```

Local APK: `app/build/outputs/apk/debug/app-debug.apk`.

## Verification status

Project XML, resources, configuration, workflow YAML, shell command syntax, assetlinks generator and ZIP contents were checked locally. **Android compilation, Android lint, APK installation and device login/sync have not been run in this workspace** because the Android SDK/Gradle build environment is not installed here. The included workflow performs compilation, lint and signature verification on GitHub. Build logs will show any SDK/dependency/network issue.

Install checklist: open app → sign in → check all five tabs → save a check-in → pair a second real account → confirm the shared mood updates → reopen app. Check the current site in the same browser first if login needs troubleshooting.

## Useful official references

- [Android Browser Helper](https://github.com/GoogleChrome/android-browser-helper)
- [Trusted Web Activity integration and Digital Asset Links](https://developer.chrome.com/docs/android/trusted-web-activity/integration-guide)
- [Android TWA behaviour and browser fallback](https://developer.android.com/develop/ui/views/layout/webapps/guide-trusted-web-activities-version2)
- [AGP 8.13 compatibility](https://developer.android.com/build/releases/agp-8-13-0-release-notes)
- [GitHub Actions: Java with Gradle](https://docs.github.com/en/actions/tutorials/build-and-test-code/java-with-gradle)

Android Browser Helper and its transitive dependencies retain their own licenses. Their source is resolved from official dependency repositories during the build; this ZIP does not bundle those libraries.
