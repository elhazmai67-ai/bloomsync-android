package com.bloomsync.companion;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.google.androidbrowserhelper.trusted.LauncherActivity;

/** Opens the hosted BloomSync app in the user's browser-backed app session. */
public final class MainActivity extends LauncherActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // This launcher has no deep-link or share-target contract. Ignore incoming
        // URL/extras so another app cannot redirect this entry point to another site.
        setIntent(new Intent(this, MainActivity.class).setAction(Intent.ACTION_MAIN));
        super.onCreate(savedInstanceState);
    }

    @Override
    protected Uri getLaunchingUrl() {
        return Uri.parse(getString(R.string.launch_url));
    }
}
